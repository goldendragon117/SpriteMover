﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisableingMove : MonoBehaviour {
    private Movement dismove;//var to hold the componet 
	// Use this for initialization
	void Start () {

        dismove = GetComponent<Movement>();//get the Movement componnet 
    }
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKeyDown(KeyCode.P))//P is pressed
        {
            dismove.enabled = !dismove.enabled;//toggles the P key if up or down
        }
	}
}
