﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {
    private Transform tf; // A variable to hold our Transform component
    // Use this for initialization
    void Start () {
        tf = GetComponent<Transform>();//at the start enables to access the transform in unity
    }

    // Update is called once per frame
    void FixedUpdate () {
        //a set of If statement to get input
        if (Input.GetKey(KeyCode.UpArrow))//If up key is held down
        {
            Debug.Log("UpArrow key is pressed");//displayed in the console for errors
            //creates a vector for movement and normallizes it 
            Vector3 myVector = new Vector3(0, 2, 0);
            myVector = myVector.normalized;
            tf.position = tf.position + (myVector * 0.1f);//changes the position based on the vector and speed
        }
        if (Input.GetKey(KeyCode.RightArrow))//If right key is held down
        {
            Debug.Log("RightArrow key is pressed");//displayed in the console for errors
            //creates a vector for movement and normallizes it 
            Vector3 myVector = new Vector3(2, 0, 0);
            myVector = myVector.normalized;
            tf.position = tf.position + (myVector * 0.1f);//changes the position based on the vector and speed
        }
        if (Input.GetKey(KeyCode.DownArrow))//If down key is held down
        {
            Debug.Log("DownArrow key is pressed");//displayed in the console for errors
            //creates a vector for movement and normallizes it 
            Vector3 myVector = new Vector3(0, -2, 0);
            myVector = myVector.normalized;
            tf.position = tf.position + (myVector * 0.1f);//changes the position based on the vector and speed
        }
        if (Input.GetKey(KeyCode.LeftArrow))//If left key is held down
        {
            Debug.Log("LeftArrow key is pressed");//displayed in the console for errors
            //creates a vector for movement and normallizes it 
            Vector3 myVector = new Vector3(-2, 0, 0);
            myVector = myVector.normalized;
            tf.position = tf.position + (myVector * 0.1f);//changes the position based on the vector and speed
        }
        //set of If statments for Shift and Arrow
        if (Input.GetKey(KeyCode.LeftShift))//If shift key is held down
        {
            if(Input.GetKeyDown(KeyCode.LeftArrow))//if left key is pressed
            {
                tf.position = tf.position + Vector3.left;//changes the position to one unit in said derication

            }
            Debug.Log("LeftShift key is pressed");//displayed in the console for errors

        }
        if (Input.GetKey(KeyCode.LeftShift))//If shift key is held down
        {
            if (Input.GetKeyDown(KeyCode.RightArrow))//if right key is pressed
            {
                tf.position = tf.position + Vector3.right;//changes the position to one unit in said derication

            }

        }
        if (Input.GetKey(KeyCode.LeftShift))//If shift key is held down
        {
            if (Input.GetKeyDown(KeyCode.UpArrow))//if up key is pressed
            {
                tf.position = tf.position + Vector3.up;//changes the position to one unit in said derication

            }

        }
        if (Input.GetKey(KeyCode.LeftShift))//If shift key is held down
        {
            if (Input.GetKeyDown(KeyCode.DownArrow))//if down key is pressed
            {
                tf.position = tf.position + Vector3.down;//changes the position to one unit in said derication

            }

        }
        if (Input.GetKeyDown(KeyCode.Space))//if player presses space bar
        {
            Debug.Log("Space key is pressed");//displayed in the console for errors
            Transform tf = GetComponent<Transform>(); // Get the Transform component from the object as this code is on
            tf.position = Vector3.zero; // Vector3.zero is a preset value of (0,0,0)
        }
    }
}
